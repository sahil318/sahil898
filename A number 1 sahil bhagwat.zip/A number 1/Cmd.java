class Cmd
{
public static void main(String[] args)
	{
		String name = args[0];
		System.out.print("Welcome "+name);

	}
}