package com.company;
import java.util.*;

 class Simple
{

    public static void main(String[] args)
    {
        double p;
        double simple;
        double r;
        double n;

		Scanner a = new Scanner(System.in);
		System.out.println("ENTER PRINCIPLE AMOUNT");
		p= a.nextDouble();
        System.out.println("RATE OF INTEREST");
        r= a.nextDouble();
        System.out.println("TIME PERIOD");
        n= a.nextDouble();
        simple = ((p*r*n)/100);
        System.out.println("SIMPLE INTEREST = "+simple);





    }
}
