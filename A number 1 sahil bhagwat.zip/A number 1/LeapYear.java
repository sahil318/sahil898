 class LeapYear
{

    public static void main(String[] args)
    {
        int a;
        Scanner b = new Scanner(System.in);
        System.out.println("ENTER THE YEAR");
        a = b.nextInt();
        if (a%4==0)
        {
            System.out.println(+a+" "+"IS A LEAP YEAR");
        }
        else
        {
            System.out.println(+a+" "+"IS  NOT A LEAP  YEAR");
        }

    }
}