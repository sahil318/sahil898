//print roll number and integer value

class Student_roll
{

    public static void main(String[] args)
    {
        int rollNo = 100;
	    System.out.println("roll no ="+" "+rollNo);
    }
}