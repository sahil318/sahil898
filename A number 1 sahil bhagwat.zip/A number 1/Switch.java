package assignment;
import java.util.*;

public class Switch
{

    public static void main(String[] args)
    {

		Scanner sc = new Scanner(System.in);
		int xx = sc.nextInt();


	    switch(xx)
            {
			case 1:
				boolean x, y, z;
				x = false;
				y = true;
				z = x && y || !(x || y);
				System.out.println(z);
				break;

			case 2:
				int a = 2;
				int b;
				b = a * a + 3 * a - 7;
				System.out.println(b);
				break;

			case 3:
				int e, f;
				e = 5;
				f = e++ - --e - --e + e++;
				System.out.println(f);
				break;
                        default :
                            System.out.println("DO YOU WANT TO CONTINUE");
		}

            
            


	}
}

