package Ternary;
import java.util.*;


public class Great 
{
 public static void main (String args [])
 {
	 int a,b,c;
	Scanner sc = new Scanner(System.in);
	a = sc.nextInt();
	b = sc.nextInt();
	c = sc.nextInt();
	 int s=(a>b)?(a>c? a:c):(b>c? b:c);
	 System.out.print(s);
	 
	 
 }
}
