import java.util.*;
class GreatestIE
{
    public static void main(String[] args)
    {
        int num1,num2,num3;
        Scanner x = new Scanner(System.in);
        System.out.println("ENTER NUM1 = ");
        num1 = x.nextInt();
        System.out.println("ENTER NUM2 = ");
        num2 = x.nextInt();
        System.out.println("ENTER NUM2 = ");
        num3 = x.nextInt();

        if (num1>num2&&num1>num3)
        {
            System.out.println("GREATEST NUMBER IS NUM1 = "+num1);

        }
        else
        {
            if ((num2>num1&&num2>num3))
            {
                System.out.println("GREATEST NUMBER IS NUM2= "+num2);
            }
                else
            {
                if ((num3>num1&&num3>num1))
                    System.out.println("GREATEST NUMBER IS NUM3 = "+num3);
            }

        }

    }
