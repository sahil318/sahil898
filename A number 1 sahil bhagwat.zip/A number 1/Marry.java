import java.util.*;
public class Marry
{

    public static void main(String[] args)
    {
	// write your code here
       Scanner a = new Scanner (System.in);
        int age ;
        char gen;
        System.out.println("MINIMUM AGE REQUIRED IS 20");
        System.out.println("ENTER THE GENDER = ");
        gen = a.next().charAt(0);
        System.out.println("ENTER THE AGE = ");
        age = a.nextInt();
        if (gen=='m'||gen=='f')
        {
            if (age>=20)
               System.out.println("can marry");
            else
                System.out.println("can't marry");
        }

    }

