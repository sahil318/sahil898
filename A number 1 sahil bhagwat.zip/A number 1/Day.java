class Day
{

    public static void main(String[] args)
    {
        int days;
        int ch;
        float b = 30.0f;
        float total = 365.0f ;
        Scanner a = new Scanner(System.in);
        days = a.nextInt();
        ch = a.nextInt();
        switch(ch)
        {
            case 1:
               float year = (days /total);
                System.out.println("therefore the year calculated is " + year);
                break;
            case 2:
                float month = (float) (days / b);
                System.out.println("therefore the months calculated is " + month);
                break;
            case 3:
                float day = (float) days;
                System.out.println("therefore the day calculated is " + day);
                break;
            default:
                System.out.println("INVALID ENTRY");
        }

    }
}
